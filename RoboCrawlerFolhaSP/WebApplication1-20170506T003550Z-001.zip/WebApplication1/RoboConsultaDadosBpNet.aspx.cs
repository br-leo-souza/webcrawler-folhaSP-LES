﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Net;
using System.IO;
using System.Drawing;
using System.Text;
using System.Net.Mail;
using System.Threading;
using System.Data;
using System.ComponentModel;


namespace roboConsultaBgn
{
    public partial class RoboConsultaDadosBpNet : System.Web.UI.Page
    {

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                if (Request.QueryString["cpf"] != null)
                {

                    VerificarSeRoboBpNetEstaLogado();
                }
            }

            #region metodos grid
            //protected void CarregaGrid()
            //{
            //    RoboBicDataContext rpd = new RoboBicDataContext();

            //    var query = (from n in rpd.ARQUIVO_ROBO_BICs
            //                 where n.ARRO_TXT_STATUS == "S" && n.ARRO_TXT_CONVENIO == "mex"
            //                 group n by new
            //                 {
            //                     Id_Arquivo = n.ARRO_ID_ARQUIVO_ROBO,
            //                     descricao = n.ARRO_TXT_DESCRICAO,
            //                     total = n.DADOS_TEMP_ROBO_BICs.Count(),
            //                     falta = n.DADOS_TEMP_ROBO_BICs.Count(c => c.DTRB_TXT_STATUS_CONSULTA == "N"),
            //                     dt_criado = n.ARRO_DT_DATA_CRIACAO

            //                 } into g
            //                 orderby g.Key.Id_Arquivo
            //                 select new
            //                 {
            //                     Id_Arquivo = g.Key.Id_Arquivo,
            //                     descricao = g.Key.descricao,
            //                     total = g.Key.total,
            //                     falta = g.Key.falta,
            //                     dt_criado = g.Key.dt_criado,
            //                     StatusOf = ResolveUrl("~/images/ImagemOff.png"),
            //                     StatusOn = ResolveUrl("~/images/imgCarreganoAnimado.gif")

            //                 }).ToList();

            //    this.gdvConsultas.DataSource = query;
            //    this.gdvConsultas.DataBind();

            //    if (gdvConsultas.Rows.Count > 0)
            //    {
            //        gdvConsultas.HeaderRow.Cells[5].ColumnSpan = 3;
            //        gdvConsultas.HeaderRow.Cells[6].ColumnSpan = 2;
            //        gdvConsultas.HeaderRow.Cells[7].Visible = false;
            //        gdvConsultas.HeaderRow.Cells[8].Visible = false;
            //        gdvConsultas.HeaderRow.Cells[9].Visible = false;
            //        gdvConsultas_RowCommand(null, null);

            //    }
            //    else
            //    {
            //    }
            //}

            //protected void gdvConsultas_RowCommand(object sender, GridViewCommandEventArgs e)
            //{
            //    int cont = gdvConsultas.Rows.Count;

            //    if (sender == null && e == null)
            //    {
            //        StatusConsultas(false, null, cont);
            //    }
            //    else
            //    {
            //        StatusConsultas(true, e, cont);

            //    }
            //}

            //protected void StatusConsultas(bool tipo, GridViewCommandEventArgs e, int cont)
            //{
            //    if (tipo)
            //    {
            //        int index = Convert.ToInt32(e.CommandArgument);
            //        GridViewRow gvr = gdvConsultas.Rows[index];
            //        if (Application["malaAtivaBicExercito"] == null || Application["malaAtivaBicExercito"] != null && gvr.Cells[9].Visible)
            //        {
            //            if (e.CommandName.Equals("StartRobo"))
            //            {
            //                gvr.Cells[5].Enabled = false;
            //                gvr.Cells[6].Enabled = true;
            //                gvr.Cells[8].Visible = false;
            //                gvr.Cells[9].Visible = true;
            //                gvr.Cells[8].ColumnSpan = 2;
            //                var gdvConsultasDataKey = gdvConsultas.DataKeys[index];
            //                if (gdvConsultasDataKey != null)
            //                    Application["malaAtivaBicExercito"] = gdvConsultasDataKey.Value.ToString();
            //                Application["nomeRobo"] = HttpUtility.HtmlDecode(gvr.Cells[1].Text);
            //                var nomeRobo = Application["nomeRobo"];
            //                if (nomeRobo != null)
            //                    Literal3.Text = "Quantidade de clientes para consultar da mala " + nomeRobo.ToString();

            //                btnRodar_Click(null, null);

            //                AtualizarQuantoFalta();


            //            }
            //            else if (e.CommandName.Equals("StopRobo"))
            //            {
            //                gvr.Cells[5].Enabled = true;
            //                gvr.Cells[6].Enabled = false;
            //                gvr.Cells[8].Visible = true;
            //                gvr.Cells[9].Visible = false;
            //                gvr.Cells[8].ColumnSpan = 2;

            //                Application["malaAtivaBicExercito"] = null;
            //                Application["nomeRobo"] = null;

            //                Literal3.Text = "Quantidade de clientes para consultar";
            //                AtualizarQuantoFalta();
            //            }
            //            else if (e.CommandName.Equals("GerarRobo"))
            //            {
            //                var gdvConsultasDataKey = gdvConsultas.DataKeys[index];
            //                if (gdvConsultasDataKey != null)
            //                {
            //                    string idMala = gdvConsultasDataKey.Value.ToString();
            //                    string url2 = "http://192.168.2.15/mdsistemaext/GerarExcelSpiderPan.aspx?idMala=" + idMala + "&solicitador=SpiderBicMex";
            //                    Response.Redirect(url2);
            //                }
            //            }
            //            else if (e.CommandName.Equals("ExcluirMala"))
            //            {
            //                var gdvConsultasDataKey = gdvConsultas.DataKeys[index];
            //                if (gdvConsultasDataKey != null)
            //                {
            //                    string idMala = gdvConsultasDataKey.Value.ToString();
            //                    RoboBicDataContext rpc = new RoboBicDataContext();
            //                    var queryMala = from n in rpc.ARQUIVO_ROBO_BICs
            //                                    where n.ARRO_ID_ARQUIVO_ROBO == Convert.ToInt64(idMala)
            //                                    select n;

            //                    if (queryMala.Any())
            //                    {
            //                        var malaParaExcluir = queryMala.First();

            //                        malaParaExcluir.ARRO_TXT_STATUS = "N";
            //                        rpc.SubmitChanges();
            //                        AtualizarQuantoFalta();
            //                    }
            //                }
            //            }
            //        }
            //        else
            //        {
            //            var malaAtual = HttpUtility.HtmlDecode(gvr.Cells[1].Text);
            //            litMensagem.Text = "Para iniciar a mala " + malaAtual + ", primeiro pare a mala " + Application["nomeRobo"] + " que está em execução.";
            //            ScriptManager.RegisterStartupScript(Page, Page.GetType(), Guid.NewGuid().ToString(), "alertMensagem()", true);
            //        }

            //    }
            //    else
            //    {
            //        int index = 0;

            //        while (index < cont)
            //        {
            //            GridViewRow gvr = gdvConsultas.Rows[index];
            //            gvr.Cells[5].Enabled = true;
            //            gvr.Cells[6].Enabled = false;
            //            gvr.Cells[8].Visible = true;
            //            gvr.Cells[9].Visible = false;
            //            gvr.Cells[8].ColumnSpan = 2;

            //            index++;

            //        }

            //    }

            //}

            //protected void lkbAtualizarGrid_Click(object sender, EventArgs e)
            //{
            //    if (Application["malaAtivaBicExercito"] == null)
            //    {
            //        CarregaGrid();
            //    }
            //    else
            //    {
            //        litMensagem.Text = "Para atualizar a lista de consultas, pare a mala em execução!";
            //        ScriptManager.RegisterStartupScript(Page, Page.GetType(), Guid.NewGuid().ToString(), "alertMensagem()", true);
            //    }
            //}

            #endregion
        }

        private void VerificarSeRoboBpNetEstaLogado()
        {
            if (Application["RoboBpNetLogado"] == null)
                LogarRoboBpNet();
        }

        private void LogarRoboBpNet()
        {
            CookieContainer cookies = new CookieContainer();
            

            string LOGIN_URL = "https://www.bradescopromotoranet.com.br/Login.aspx";


            string responseData = AcessarUrl(cookies, LOGIN_URL);

            string viewstate = Extract("__VIEWSTATE", responseData);
            string eventvalidation = Extract("__EVENTVALIDATION", responseData);
            //__VIEWSTATEFIELDCOUNT

            string usuario = "60032RJ@FACTA";
            string senha = "100417";

            //USUÁRIO ESTÁ INATIVO. POR FAVOR, ENTRE EM CONTATO COM A ÁREA DE SEGURANÇA DA INFORMAÇÃO.

            string postData = String.Format("__EVENTTARGET=" +
                                     "&__EVENTARGUMENT=" +
                                     "&__VIEWSTATE={0}" +
                                     "&__EVENTVALIDATION={1}" +
                                     "&ctl00%24ctl00%24cphBodyMain%24cphBody%24txtLogin={2}" +
                                     "&ctl00%24ctl00%24cphBodyMain%24cphBody%24txtSenha={3}" +
                                     "&ctl00%24ctl00%24cphBodyMain%24cphBody%24btnEntrar=" +
                                     "", viewstate, eventvalidation, usuario, senha);



            responseData = AcessarUrl(cookies, LOGIN_URL, postData);


            LOGIN_URL = "https://www.bradescopromotoranet.com.br/Forms/Proposta/CadastroProposta.aspx?prop=uqnWIp%2fhlKc%3d&prod=QPTSe18vz14%3d";

            responseData = AcessarUrl(cookies, LOGIN_URL);


            //LOGIN_URL = "https://www.bradescopromotoranet.com.br/Forms/Proposta/CadastroProposta.aspx?prop=uqnWIp%2fhlKc%3d&prod=QPTSe18vz14%3d";

            string valViewStateFieldCount = Extract("__VIEWSTATEFIELDCOUNT", responseData);
            viewstate = Extract("__VIEWSTATE\"", responseData);
            viewstate = MotarViewState(responseData, viewstate, valViewStateFieldCount);
            eventvalidation = Extract("__EVENTVALIDATION", responseData);

            string cpf = Request.QueryString["cpf"].ToString();


            postData = string.Format("__EVENTTARGET=&" +
                                     "__EVENTARGUMENT=&" +
                                     "__LASTFOCUS=&" +
                                     "{0}&" +
                                     "__SCROLLPOSITIONX=0&" +
                                     "__SCROLLPOSITIONY=0&" +
                                     "__VIEWSTATEENCRYPTED=&" +
                                     "__EVENTVALIDATION={1}&" +
                                     "ctl00$ctl00$ctl00$cphBodyMain$cpPromotoras$ddlPromotora=&" +
                                     "ctl00$ctl00$ctl00$cphBodyMain$cphBody$cphBody$hidTipoUsuario=UsuarioComum&" +
                                     "__CALLBACKID=ctl00$ctl00$ctl00$cphBodyMain$uccma&" +
                                     "__CALLBACKPARAM=",
                                     viewstate, eventvalidation);

            responseData = AcessarUrl(cookies, LOGIN_URL, postData);


            LOGIN_URL = "https://www.bradescopromotoranet.com.br/Forms/Proposta/CadastroProposta.aspx?prop=uqnWIp%2fhlKc%3d&prod=QPTSe18vz14%3d";


            postData = string.Format("ctl00$ctl00$ctl00$ScriptManager1=ctl00$ctl00$ctl00$cphBodyMain$cpPromotoras$upFilial|ctl00$ctl00$ctl00$cphBodyMain$cpPromotoras$ddlPromotora&" +
                                     "__EVENTTARGET=ctl00$ctl00$ctl00$cphBodyMain$cpPromotoras$ddlPromotora&" +
                                     "__EVENTARGUMENT=&" +
                                     "__LASTFOCUS=&" +
                                     "{0}&" +
                                     "__SCROLLPOSITIONX=0&" +
                                     "__SCROLLPOSITIONY=0&" +
                                     "__VIEWSTATEENCRYPTED=&" +
                                     "__EVENTVALIDATION={1}&" +
                                     "ctl00$ctl00$ctl00$cphBodyMain$cpPromotoras$ddlGrupo=19&" +
                                     "ctl00$ctl00$ctl00$cphBodyMain$cpPromotoras$ddlPromotora=1120&" +
                                     "ctl00$ctl00$ctl00$cphBodyMain$cphBody$cphBody$hidTipoUsuario=UsuarioComum&" +
                                     "__ASYNCPOST=true",
                                     viewstate, eventvalidation);



            responseData = AcessarUrl(cookies, LOGIN_URL, postData);



            //string link = "https://www.bradescopromotoranet.com.br/Forms/CImagem.aspx";
            //string nomeimagem = DateTime.Now.ToString("yyyymmddmmss");
            //AcessarUrlImagem(cookies, link, nomeimagem);// AcessarUrl(cookies, LOGIN_URL);

            //imageCaptcha.ImageUrl = "Captcha/" + nomeimagem + ".jpg";
            //imageCaptcha.Visible = true;

            responseData = AcessarUrl(cookies, LOGIN_URL);

            valViewStateFieldCount = Extract("__VIEWSTATEFIELDCOUNT", responseData);
            viewstate = Extract("__VIEWSTATE\"", responseData);
            viewstate = MotarViewState(responseData, viewstate, valViewStateFieldCount);
            eventvalidation = Extract("__EVENTVALIDATION", responseData);
            string previousPage = Extract("__PREVIOUSPAGE", responseData);

            postData = string.Format("ctl00$ctl00$ctl00$ScriptManager1=ctl00$ctl00$ctl00$ScriptManager1|ctl00$ctl00$ctl00$cphBodyMain$cphBody$cphBody$ucDadosValidacao$drpConvenio&" +
                                     "__EVENTTARGET=ctl00$ctl00$ctl00$cphBodyMain$cphBody$cphBody$ucDadosValidacao$drpConvenio&" +
                                     "__EVENTARGUMENT=&" +
                                     "__LASTFOCUS=&" +
                                     "{0}&" +
                                     "__SCROLLPOSITIONX=0&" +
                                     "__SCROLLPOSITIONY=0&" +
                                     "__VIEWSTATEENCRYPTED=&" +
                                     "__PREVIOUSPAGE{1}&" +
                                     "__EVENTVALIDATION{2}&" +
                                     "ctl00$ctl00$ctl00$cphBodyMain$cpPromotoras$ddlGrupo=19&" +
                                     "ctl00$ctl00$ctl00$cphBodyMain$cpPromotoras$ddlPromotora=1120&" +
                                     "ctl00$ctl00$ctl00$cphBodyMain$cphBody$cphBody$hidTipoUsuario=UsuarioComum&" +
                                     "ctl00$ctl00$ctl00$cphBodyMain$cphBody$cphBody$ucDadosValidacao$drpConvenio=4437&" +
                                     "__ASYNCPOST=true",
                                     viewstate, previousPage, eventvalidation);

            responseData = AcessarUrl(cookies, LOGIN_URL, postData);

            VariaveisConsulta.CookiePosCaptcha = cookies;
            VariaveisConsulta.ResponseDataCaptcha = responseData;
            VariaveisConsulta.EventValidationCaptcha = eventvalidation;
            VariaveisConsulta.ViewStateCaptcha = viewstate;
        }


        protected void btnCaptcha_Click(object sender, EventArgs e)
        {
            ContinuarPreConsulta();
        }

        private void ContinuarPreConsulta()
        {
            if (VariaveisConsulta.CookiePosCaptcha != null && VariaveisConsulta.ResponseDataCaptcha != null)
            {
                CookieContainer cookie = VariaveisConsulta.CookiePosCaptcha;
                string responseData = VariaveisConsulta.ResponseDataCaptcha;
                //string valViewStateFieldCount = Extract("__VIEWSTATEFIELDCOUNT", responseData);
                //string viewstate = Extract("__VIEWSTATE\"", responseData);
                string viewstate = VariaveisConsulta.ViewStateCaptcha;//MotarViewState(responseData, viewstate, valViewStateFieldCount);
                string eventvalidation = VariaveisConsulta.EventValidationCaptcha;// Extract("__EVENTVALIDATION", responseData);

                string captcha = txtCaptcha.Text.ToString();
                string cpf = Request.QueryString["cpf"].ToString();
                string PREVIOUSPAGE = Extract("__PREVIOUSPAGE", responseData);
                string link = "https://www.bradescopromotoranet.com.br/Forms/Proposta/CadastroProposta.aspx?prop=uqnWIp%2fhlKc%3d&prod=QPTSe18vz14%3d";

                string postData = string.Format("ctl00$ctl00$ctl00$ScriptManager1=ctl00$ctl00$ctl00$cphBodyMain$cphBody$cphBody$ucDadosRefinanciamento$UpdatePanel2|ctl00$ctl00$ctl00$cphBodyMain$cphBody$cphBody$ucDadosRefinanciamento$txtCpf&" +
                                                "ctl00$ctl00$ctl00$cphBodyMain$cpPromotoras$ddlGrupo=19&" +
                                                "ctl00$ctl00$ctl00$cphBodyMain$cpPromotoras$ddlPromotora=1120&" +
                                                "ctl00$ctl00$ctl00$cphBodyMain$cphBody$cphBody$hidTipoUsuario=UsuarioComum&" +
                                                "ctl00$ctl00$ctl00$cphBodyMain$cphBody$cphBody$ucDadosValidacao$drpConvenio=4437&" +
                                                "ctl00$ctl00$ctl00$cphBodyMain$cphBody$cphBody$ucDadosValidacao$drpEmpresa=45&" +
                                                "ctl00$ctl00$ctl00$cphBodyMain$cphBody$cphBody$ucDadosValidacao$drpProduto=10&" +
                                                "ctl00$ctl00$ctl00$cphBodyMain$cphBody$cphBody$ucDadosValidacao$drpLoja=1QPX&" +
                                                "ctl00$ctl00$ctl00$cphBodyMain$cphBody$cphBody$ucDadosValidacao$drpFilial=0000&" +
                                                "ctl00$ctl00$ctl00$cphBodyMain$cphBody$cphBody$ucCaptcha$txtCaptcha={0}&" +
                                                "ctl00$ctl00$ctl00$cphBodyMain$cphBody$cphBody$ucDadosRefinanciamento$txtCpf={1}&" +
                                                "__EVENTTARGET=ctl00$ctl00$ctl00$cphBodyMain$cphBody$cphBody$ucDadosRefinanciamento$txtCpf&" +
                                                "__EVENTARGUMENT=&" +
                                                "__LASTFOCUS=&" +
                                                "__SCROLLPOSITIONX=0&" +
                                                "__SCROLLPOSITIONY=0&" +
                                                "__PREVIOUSPAGE={2}&" +
                                                "_EVENTVALIDATION{3}&" +
                                                "{4}&" +
                                                "__VIEWSTATEENCRYPTED=&" +
                                                "__ASYNCPOST=true",
                                                captcha, cpf, PREVIOUSPAGE, eventvalidation, viewstate);
                responseData = AcessarUrl(cookie, link, postData);
                //ctl00$ctl00$ctl00$cphBodyMain$cphBody$cphBody$ucDadosFinanciamento$txtTabela:
                //ctl00$ctl00$ctl00$cphBodyMain$cphBody$cphBody$ucDadosFinanciamento$txtPrazo:
                //ctl00$ctl00$ctl00$cphBodyMain$cphBody$cphBody$ucDadosFinanciamento$txtValorSolicitado:
                //ctl00$ctl00$ctl00$cphBodyMain$cphBody$cphBody$ucDadosFinanciamento$txtValorLiquidoOC:
                //ctl00$ctl00$ctl00$cphBodyMain$cphBody$cphBody$ucDadosFinanciamento$txtValorParcelaOC:
                //ctl00$ctl00$ctl00$cphBodyMain$cphBody$cphBody$ucDadosFinanciamento$txtValorTCOC:
                //ctl00$ctl00$ctl00$cphBodyMain$cphBody$cphBody$ucDadosFinanciamento$txtDataContrato:
                //ctl00$ctl00$ctl00$cphBodyMain$cphBody$cphBody$ucDadosFinanciamento$txtData1Venc:
                //ctl00$ctl00$ctl00$cphBodyMain$cphBody$cphBody$ucDadosFinanciamento$txtValorSeguro:
                //ctl00$ctl00$ctl00$cphBodyMain$cphBody$cphBody$ucDadosFinanciamento$txtCET:
                //ctl00$ctl00$ctl00$cphBodyMain$cphBody$cphBody$ucDadosFinanciamento$hfValorIOC:
                //ctl00$ctl00$ctl00$cphBodyMain$cphBody$cphBody$ucDadosFinanciamento$hfValorTaxaMes:
                //ctl00$ctl00$ctl00$cphBodyMain$cphBody$cphBody$ucDadosFinanciamento$hfValorFinanciado:
                //ctl00$ctl00$ctl00$cphBodyMain$cphBody$cphBody$ucDadosFinanciamento$hfValorCoeficiente:
                //ctl00$ctl00$ctl00$cphBodyMain$cphBody$cphBody$ucDadosFinanciamento$hfValorComissao:
                //ctl00$ctl00$ctl00$cphBodyMain$cphBody$cphBody$ucDadosFinanciamento$hfValorTaxaRetencao:
                //ctl00$ctl00$ctl00$cphBodyMain$cphBody$cphBody$ucDadosFinanciamento$hfValorRetencao:
                postData = string.Format("tl00$ctl00$ctl00$ScriptManager1=ctl00$ctl00$ctl00$ScriptManager1|ctl00$ctl00$ctl00$cphBodyMain$cphBody$cphBody$ucDadosRefinanciamento$btnPesquisarCpf&" +
                                                "ctl00$ctl00$ctl00$cphBodyMain$cpPromotoras$ddlGrupo=19&" +
                                                "ctl00$ctl00$ctl00$cphBodyMain$cpPromotoras$ddlPromotora=1120&" +
                                                "ctl00$ctl00$ctl00$cphBodyMain$cphBody$cphBody$hidTipoUsuario=UsuarioComum&" +
                                                "ctl00$ctl00$ctl00$cphBodyMain$cphBody$cphBody$ucDadosValidacao$drpConvenio=4437&" +
                                                "ctl00$ctl00$ctl00$cphBodyMain$cphBody$cphBody$ucDadosValidacao$drpEmpresa=45&" +
                                                "ctl00$ctl00$ctl00$cphBodyMain$cphBody$cphBody$ucDadosValidacao$drpProduto=10&" +
                                                "ctl00$ctl00$ctl00$cphBodyMain$cphBody$cphBody$ucDadosValidacao$drpLoja=1QPX&" +
                                                "ctl00$ctl00$ctl00$cphBodyMain$cphBody$cphBody$ucDadosValidacao$drpFilial=0000&" +
                                                "ctl00$ctl00$ctl00$cphBodyMain$cphBody$cphBody$ucCaptcha$txtCaptcha={0}&" +
                                                "ctl00$ctl00$ctl00$cphBodyMain$cphBody$cphBody$ucDadosRefinanciamento$txtCpf={1}&" +
                                                "__EVENTTARGET=&" +
                                                "__EVENTARGUMENT=&" +
                                                "__LASTFOCUS=&" +
                                                "{2}&" +
                                                "__SCROLLPOSITIONX=0&" +
                                                "__SCROLLPOSITIONY=0&" +
                                                "__EVENTVALIDATION={3}&" +
                                                "__ASYNCPOST=true&" +
                                                "ctl00$ctl00$ctl00$cphBodyMain$cphBody$cphBody$ucDadosRefinanciamento$btnPesquisarCpf="
                                                , captcha, cpf, viewstate, eventvalidation);



                responseData = AcessarUrl(cookie, link, postData);
            }
        }



        private string MotarViewState(string responseData, string viewstate, string VIEWSTATEFIELDCOUNT)
        {
            string parametroCompleto = "";
            if (VIEWSTATEFIELDCOUNT != null && VIEWSTATEFIELDCOUNT != string.Empty)
            {
                int contador = Convert.ToInt32(VIEWSTATEFIELDCOUNT);

                for (int i = 1; i < contador; i++)
                {
                    viewstate = viewstate + "&__VIEWSTATE" + i.ToString() + "=" + Extract("__VIEWSTATE" + i.ToString(), responseData);
                }
                parametroCompleto = "__VIEWSTATEFIELDCOUNT=" + contador.ToString() + "&__VIEWSTATE=" + viewstate;

            }
            return parametroCompleto;
        }

        #region Metodos Post robo

        private string AcessarUrl(CookieContainer cookies, string url)
        {
            HttpWebRequest webRequest = WebRequest.Create(url) as HttpWebRequest;
            webRequest.CookieContainer = cookies;
            webRequest.Method = "GET";
            webRequest.AllowAutoRedirect = true;
            webRequest.MaximumAutomaticRedirections = 200;
            webRequest.UserAgent = "Mozilla/5.0 (Windows NT 5.1) AppleWebKit/535.6 (KHTML, like Gecko) Chrome/16.0.897.0 Safari/535.6";
            StreamReader responseReader = new StreamReader(webRequest.GetResponse().GetResponseStream());
            string responseData = responseReader.ReadToEnd();
            responseReader.Close();
            System.Threading.Thread.Sleep(1000);
            return responseData;
        }

        private string AcessarUrl(CookieContainer cookies, string url, string postData)
        {
            //again access the login page with posted data to get cookies
            HttpWebRequest webRequest = WebRequest.Create(url) as HttpWebRequest;
            webRequest.AllowAutoRedirect = true;
            webRequest.MaximumAutomaticRedirections = 200;
            webRequest.Method = "POST";
            webRequest.ContentType = "application/x-www-form-urlencoded";
            webRequest.UserAgent = "Mozilla/5.0 (Windows NT 5.1) AppleWebKit/535.6 (KHTML, like Gecko) Chrome/16.0.897.0 Safari/535.6";


            //get cookies to present in the other page
            webRequest.CookieContainer = cookies;
            StreamWriter requestWriter = new StreamWriter(webRequest.GetRequestStream());


            //access the login page with posted data
            requestWriter.Write(postData);
            requestWriter.Close();
            StreamReader responseReader = new StreamReader(webRequest.GetResponse().GetResponseStream());
            string responseData = responseReader.ReadToEnd();
            responseReader.Close();
            System.Threading.Thread.Sleep(1000);
            return responseData;
        }

        private static bool CustomValidation(object sender, System.Security.Cryptography.X509Certificates.X509Certificate cert,
       System.Security.Cryptography.X509Certificates.X509Chain chain, System.Net.Security.SslPolicyErrors error)
        {
            return true;
        }

        private string AcessarUrlImagem(CookieContainer cookies, string url, string nomeimage)
        {
            ServicePointManager.ServerCertificateValidationCallback += new System.Net.Security.RemoteCertificateValidationCallback(CustomValidation);

            HttpWebRequest webRequest = WebRequest.Create(url) as HttpWebRequest;
            webRequest.CookieContainer = cookies;
            webRequest.AllowAutoRedirect = true;
            webRequest.MaximumAutomaticRedirections = 200;
            webRequest.UserAgent = "Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/27.0.1453.116 Safari/537.36"; //"Mozilla/5.0 (Windows NT 5.1) AppleWebKit/535.6 (KHTML, like Gecko) Chrome/16.0.897.0 Safari/535.6";
            Stream responseReader = webRequest.GetResponse().GetResponseStream();
            //string responseData = responseReader.ReadToEnd();


            Bitmap bitmap2 = new Bitmap(responseReader);
            bitmap2.Save(Server.MapPath("Captcha") + "\\" + nomeimage + ".jpg");

            Thread.Sleep(500);
            //Session["cookieMarinha"] = cookies;
            responseReader.Close();
            //System.Threading.Thread.Sleep(500);
            return "Nada";
        }

        #region metodos extração de parametros

        private string Extract2(string name, string page)
        {
            string viewStateNameDelimiter = name;
            string valueDelimiter = "|";


            int viewStateNamePosition = page.IndexOf(viewStateNameDelimiter);
            int viewStateValuePosition = page.IndexOf(valueDelimiter, viewStateNamePosition);


            int viewStateStartPosition = viewStateValuePosition + valueDelimiter.Length;
            int viewStateEndPosition = page.IndexOf("|", viewStateStartPosition);


            return HttpUtility.UrlEncodeUnicode(page.Substring(viewStateStartPosition, viewStateEndPosition - viewStateStartPosition));

        }

        private string ExtractViewState(string s)
        {
            string viewStateNameDelimiter = "__VIEWSTATE";
            string valueDelimiter = "value=\"";


            int viewStateNamePosition = s.IndexOf(viewStateNameDelimiter);
            int viewStateValuePosition = s.IndexOf(valueDelimiter, viewStateNamePosition);


            int viewStateStartPosition = viewStateValuePosition + valueDelimiter.Length;
            int viewStateEndPosition = s.IndexOf("\"", viewStateStartPosition);


            return HttpUtility.UrlEncodeUnicode(s.Substring(viewStateStartPosition, viewStateEndPosition - viewStateStartPosition));

        }

        protected string Extract(string name, string page)
        {
            string viewStateNameDelimiter = name;
            string valueDelimiter = "value=\"";

            int viewStateNamePosition = page.IndexOf(viewStateNameDelimiter);
            int viewStateValuePosition = page.IndexOf(valueDelimiter, viewStateNamePosition);

            int viewStateStartPosition = viewStateValuePosition + valueDelimiter.Length;
            int viewStateEndPosition = page.IndexOf("\"", viewStateStartPosition);

            return HttpUtility.UrlEncodeUnicode(page.Substring(viewStateStartPosition, viewStateEndPosition - viewStateStartPosition));
        }

        private string ExtractString(string nameDelimitar, string valueDelimiter, string nameEndPosition, string page)
        {
            string viewStateNameDelimiter = nameDelimitar;
            //string valueDelimiter = nameDelimitar;


            int viewStateNamePosition = page.IndexOf(viewStateNameDelimiter);
            int viewStateValuePosition = page.IndexOf(valueDelimiter, viewStateNamePosition);


            int viewStateStartPosition = viewStateValuePosition + valueDelimiter.Length;
            int viewStateEndPosition = page.IndexOf(nameEndPosition, viewStateStartPosition);


            return page.Substring(viewStateStartPosition, viewStateEndPosition - viewStateStartPosition);

        }

        #endregion


        #endregion Metodos Post robo

    }

    public static class VariaveisConsulta
    {
        private static CookieContainer cookiePosCaptcha;
        public static CookieContainer CookiePosCaptcha
        {
            get
            {
                return cookiePosCaptcha;
            }
            set
            {
                cookiePosCaptcha = value;
            }
        }
        private static string responseDataCaptcha;
        public static string ResponseDataCaptcha
        {
            get
            {
                return responseDataCaptcha;
            }
            set
            {
                responseDataCaptcha = value;
            }
        }
        private static string viewStateCaptcha;
        public static string ViewStateCaptcha
        {
            get
            {
                return viewStateCaptcha;
            }
            set
            {
                viewStateCaptcha = value;
            }
        }
        private static string eventValidationCaptcha;
        public static string EventValidationCaptcha
        {
            get
            {
                return eventValidationCaptcha;
            }
            set
            {
                eventValidationCaptcha = value;
            }
        }

    }
}